from .texture import texture, image, solid_color
